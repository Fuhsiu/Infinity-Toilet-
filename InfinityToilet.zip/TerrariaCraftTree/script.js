// ============================================================
// ДАННЫЕ
// ============================================================
const craftData = {
    name: "Унитаз Бесконечности",
    sprite: "toilet.png",
    count: 1,
    stationID: "osp",
    children: [
        {
            name: "Катализатор Бесконечности",
            sprite: "Catalyst.gif",
            count: 9,
            stationID: "osp",
            direction: 1,
            children: [
                { name: "Камень из босс раша", sprite: "item1.png", count: 1 },
                { name: "Экзо-призма", sprite: "item2.png", count: 34 },
                { name: "Пепел аннигиляции", sprite: "item3.png", count: 34 },
                { name: "Тёмная плазма", sprite: "item4.png", count: 69 },
                { name: "Искривлённая пустота", sprite: "item5.png", count: 69 },
                { name: "Бронированный панцирь", sprite: "item6.png", count: 69 },
                { name: "Пепел бедствия", sprite: "item7.png", count: 138 },
                { name: "Божественная жеода", sprite: "item8.png", count: 345 },
                { name: "Сомнительная пластина", sprite: "item9.png", count: 345 },
                { name: "Губительная душа", sprite: "item10.png", count: 345 },
                { name: "Гель", sprite: "item11.png", count: 345 },
                { name: "Обсидиан", sprite: "item12.png", count: 345 },
                { name: "Кристалл жизни", sprite: "item13.png", count: 345 },
                { name: "Упавшая звезда", sprite: "item14.png", count: 345 },
                { name: "Эктоплазма", sprite: "item15.png", count: 345 },
                { name: "Некроплазма", sprite: "item16.png", count: 345 },
                { name: "Солнечный фрагмент", sprite: "item17.png", count: 34 },
                { name: "Вихревой фрагмент", sprite: "item18.png", count: 103 },
                { name: "Эссенция ночи", sprite: "item19.png", count: 345 },
                { name: "Эссенция света", sprite: "item20.png", count: 345 },
                { name: "Девиантная энергия", sprite: "item21.png", count: 103 },
                { name: "Мерзкая энергия", sprite: "item22.png", count: 103 },
                { name: "Вечная энергия", sprite: "item23.png", count: 103 },
                { name: "Чудо фрукт", sprite: "item24.png", count: 34, stationID: "crucible" },
                { name: "Сплав Жизни", sprite: "item25.png", count: 345, stationID: "crucible" },
                { name: "Адский слиток", sprite: "item26.png", count: 345, stationID: "crucible" },
                { name: "Освящённый слиток", sprite: "item27.png", count: 345, stationID: "crucible" },
                { name: "Слиток метановы", sprite: "item28.png", count: 103, stationID: "crucible" },
                { name: "Люминитовый слиток", sprite: "item29.png", count: 345, stationID: "crucible" }
            ]
        },
        {
            name: "Сплав Бесконечности",
            sprite: "inf_alloy.gif",
            count: 29,
            stationID: "crucible",
            direction: -1,
            children: [
                { name: "Тенефазовый слиток", sprite: "shadowspec_bar.gif", count: 9, stationID: "crucible" },
                {
                    name: "Сплав сверхплотной нейтронной звезды",
                    sprite: "canvas.png",
                    count: 11,
                    stationID: "crucible",
                    children: [
                        { name: "Распадающееся вещество", sprite: "decaying_matter.png", count: 1, stationID: "manipulator" },
                        { name: "Шар тёмной материи", sprite: "dark_matter_ball.png", count: 12, stationID: "crucible" },
                        { name: "Экзо-призма", sprite: "item2.png", count: 1 },
                        { name: "Пепел аннигиляции", sprite: "item3.png", count: 1 },
                        { name: "Эссенция восходящего духа", sprite: "ascendant_essence.png", count: 1, stationID: "crucible" },
                        { name: "Метеоритный слиток", sprite: "sub_meteor_bar.png", count: 1, stationID: "furnace" },
                        { name: "Платиновый слиток", sprite: "platinum_bar.png", count: 1, stationID: "furnace" },
                        { name: "Аэролитовый слиток", sprite: "aerialite_bar.png", count: 1, stationID: "furnace" },
                        { name: "Слиток адского камня", sprite: "hellstone_bar.png", count: 1, stationID: "hellforge" },
                        { name: "Крионитовый слиток", sprite: "sub_cryonic.png", count: 1, stationID: "titanium" },
                        { name: "Хлорофитовый слиток", sprite: "chlorophyte_bar.png", count: 1, stationID: "furnace" },
                        { name: "Спектральный слиток", sprite: "spectre_bar.png", count: 1, stationID: "mythril" },
                        { name: "Многолетний слиток", sprite: "sub_perennial.png", count: 1, stationID: "titanium" },
                        { name: "Грибнитовый слиток", sprite: "shroomite_bar.png", count: 1, stationID: "manipulator" },
                        { name: "Люминитовый слиток", sprite: "item29.png", count: 1, stationID: "manipulator" },
                        { name: "Астральный слиток", sprite: "sub_astral_bar.png", count: 1, stationID: "manipulator" },
                        { name: "Магматитовый слиток", sprite: "scoria_bar.gif", count: 1, stationID: "titanium" },
                        { name: "Цветонитовый слиток", sprite: "UelibloomBar.png", count: 1, stationID: "manipulator" },
                        { name: "Космилитовый слиток", sprite: "cosmilite_bar.gif", count: 1, stationID: "crucible" },
                        { name: "Тенефазовый слиток", sprite: "shadowspec_bar.gif", count: 1, stationID: "crucible" },
                        { name: "Ауритовый слиток", sprite: "Auric_Bar.gif", count: 1, stationID: "crucible" }
                    ]
                },
                { name: "Призрачное вещество", sprite: "ghostly_matter.png", count: 1, stationID: "manipulator" },
                { name: "Катализатор Бесконечности", sprite: "Catalyst2.gif", count: 1, stationID: "osp" },
                { name: "Чудо фрукт", sprite: "miracle_fruit.png", count: 1, stationID: "mythril" },
                { name: "Осквернённая морошка", sprite: "cloudberry.png", count: 1, stationID: "crucible" },
                { name: "Кровавый мандарин", sprite: "blood_orange.png", count: 1, stationID: "crucible" },
                { name: "Священная клубника", sprite: "holy_strawberry.png", count: 1, stationID: "cosmic" },
                { name: "Дивная материя", sprite: "miracle_matter.png", count: 6, stationID: "crucible" }
            ]
        }
    ]
};

const recipesLookup = {
    "Камень из босс раша": ["Белка"],
    "Люминитовый слиток": [
        { name: "Люминитовая руда", sprite: "sub_luminite_ore.png", count: 4 }
    ],
    "Слиток метановы": [
        { name: "Руда метановы", sprite: "sub_metanova_ore.png", count: 8 },
        { name: "Астральное желе", sprite: "sub_astral_jelly.png", count: 3 },
        { name: "Астральный слиток", sprite: "sub_astral_bar.png", count: 1, stationID: "crucible" },
        { name: "Метеоритный слиток", sprite: "sub_meteor_bar.png", count: 2, stationID: "crucible" },
        { name: "Звёздная сажа", sprite: "sub_starsop.png", count: 5 }
    ],
    "Астральный слиток": [
        { name: "Звёздная сажа", sprite: "sub_starsop.png", count: 3 },
        { name: "Астральная руда", sprite: "sub_astral_ore.png", count: 2 }
    ],
    "Метеоритный слиток": [
        { name: "Метеоритная руда", sprite: "sub_meteor_ore.png", count: 3 }
    ],
    "Освящённый слиток": ["Оператор"],
    "Адский слиток": [
        { name: "Адский камень", sprite: "sub_hellstone.png", count: 3 },
        { name: "Обсидиан", count: 1 }
    ],
    "Адский камень": ["Подрывник"],

    "Сплав Жизни": [
        { name: "Крионитовый слиток", sprite: "sub_cryonic.png", count: 1, stationID: "crucible" },
        { name: "Многолетний слиток", sprite: "sub_perennial.png", count: 1, stationID: "crucible" },
        { name: "Магматитовый слиток", sprite: "sub_scoria.png", count: 1, stationID: "crucible" }
    ],
    "Крионитовый слиток": [
        { name: "Крионитовая руда", sprite: "sub_cryonic_ore.png", count: 4 }
    ],
    "Многолетний слиток": [
        { name: "Многолетняя руда", sprite: "sub_perennial_ore.png", count: 4 }
    ],
    "Магматитовый слиток": [
        { name: "Магматитовая руда", sprite: "sub_scoria_ore.png", count: 4 }
    ],

    "Чудо фрукт": [
        { name: "Фрукт жизни", sprite: "sub_life_fruit.png", count: 1 },
        { name: "Сплав Жизни", sprite: "life_alloy.png", count: 2 },
        { name: "Живой осколок", sprite: "sub_living_shard.png", count: 5 }
    ],
    "Тенефазовый слиток": [
        { name: "Ауритовый слиток", sprite: "Auric_Bar.gif", count: 1, stationID: "crucible" },
        { name: "Хроматическая масса", sprite: "ChromaticMass.gif", count: 1, stationID: "crucible" },
        { name: "Вечная энергия", sprite: "item23.png", count: 1 },
        { name: "Пепел аннигиляции", sprite: "item3.png", count: 1 },
        { name: "Экзо-призма", sprite: "item2.png", count: 1 }
    ],
    "Ауритовый слиток": [
        { name: "Ауритовая руда", sprite: "auric_ore.png", count: 1 },
        { name: "Фрагмент души Ярона", sprite: "yharon_soul.png", count: 1 }
    ],
    "Осквернённая морошка": [
        { name: "Фрукт жизни", sprite: "sub_life_fruit.png", count: 1 },
        { name: "Цветонитовый слиток", sprite: "UelibloomBar.png", count: 10, stationID: "manipulator" },
        { name: "Божественная жеода", sprite: "item8.png", count: 8 }
    ],
    "Цветонитовый слиток": [
        { name: "Цветонитовая руда", sprite: "UelibloomOre.png", count: 4 }
    ],
    "Кровавый мандарин": [
        { name: "Фрукт жизни", sprite: "sub_life_fruit.png", count: 1 },
        { name: "Кровавая сфера", sprite: "BloodOrb.png", count: 10 },
        { name: "Эссенция ужаса", sprite: "SoulofFright.png", count: 5 },
        { name: "Эссенция могущества", sprite: "SoulofMight.png", count: 5 },
        { name: "Эссенция прозрения", sprite: "soul_of_sight.gif", count: 5 }
    ],
    "Священная клубника": [
        { name: "Фрукт жизни", sprite: "sub_life_fruit.png", count: 1 },
        { name: "Фрагмент души Ярона", sprite: "yharon_soul.png", count: 5 },
        { name: "Эссенция восходящего духа", sprite: "ascendant_essence.png", count: 1 }
    ],
    "Призрачное вещество": [
        { name: "Распадающееся вещество", sprite: "decaying_matter.png", count: 16, stationID: "manipulator" },
        { name: "Аморфное вещество", sprite: "amorphous_matter.png", count: 8, stationID: "manipulator" },
        { name: "Тёмная плазма", sprite: "item4.png", count: 1 }
    ],
    "Грибнитовый слиток": [
        { name: "Гриб", sprite: "GlowingMushroom.png", count: 5 },
        { name: "Хлорофитовый слиток", sprite: "chlorophyte_bar.png", count: 1, stationID: "furnace" }
    ],
    "Спектральный слиток": [
        { name: "Эктоплазма", sprite: "item15.png", count: 1 },
        { name: "Хлорофитовый слиток", sprite: "chlorophyte_bar.png", count: 2, stationID: "furnace" }
    ],
    "Хлорофитовый слиток": [
        { name: "Хлорофитовая руда", sprite: "chlorophyte_ore.png", count: 4 }
    ],
    "Шар тёмной материи": [
        { name: "Тенефазовый слиток", sprite: "shadowspec_bar.gif", count: 24, stationID: "crucible" },
        { name: "Ауритовый слиток", sprite: "Auric_Bar.gif", count: 20, stationID: "crucible" },
        { name: "Фрагмент души Ярона", sprite: "yharon_soul.png", count: 8 },
        { name: "История", sprite: "Story.png", count: 1 }
    ],
    "История": [
        { name: "Тенефазовый слиток", sprite: "shadowspec_bar.gif", count: 1, stationID: "draedon" }
    ],
    "Эссенция восходящего духа": [
        { name: "Некроплазма", sprite: "item16.png", count: 2 },
        { name: "Кошмарное топливо", sprite: "nightmare_fuel.gif", count: 5 },
        { name: "Эндотермическая энергия", sprite: "endothermic_energy.gif", count: 5 },
        { name: "Фрагмент тёмного солнца", sprite: "darksun_fragment.gif", count: 2 }
    ],
    "Распадающееся вещество": [
        { name: "Мнимая частица", sprite: "imaginary_particle.png", count: 6 },
        { name: "Солнечный фрагмент", sprite: "solar_fragment.png", count: 1 },
        { name: "Вихревой фрагмент", sprite: "vortex_fragment.png", count: 1 },
        { name: "Туманный фрагмент", sprite: "nebula_fragment.png", count: 1 },
        { name: "Звёздный фрагмент", sprite: "stardust_fragment.png", count: 1 },
        { name: "Люминитовый слиток", sprite: "item29.png", count: 4 }
    ],
    "Аморфное вещество": [
        { name: "Мнимая частица", sprite: "imaginary_particle.png", count: 8 },
        { name: "Распадающееся вещество", sprite: "decaying_matter.png", count: 1 },
        { name: "Кристалл маны", sprite: "ManaCrystal.png", count: 4 }
    ],
    "Мнимая частица": [
        { name: "Эссенция могущества", sprite: "SoulofMight.png", count: 2 },
        { name: "Эссенция прозрения", sprite: "soul_of_sight.gif", count: 2 },
        { name: "Эссенция света", sprite: "item20.png", count: 2 },
        { name: "Эссенция ночи", sprite: "item19.png", count: 2 },
        { name: "Эссенция ужаса", sprite: "SoulofFright.png", count: 1 },
        { name: "Эссенция полёта", sprite: "SoulofFlight.png", count: 1 },
        { name: "Освящённый слиток", sprite: "hallowed_bar.png", count: 1 }
    ],
    "Платиновый слиток": [
        { name: "Платиновая руда", sprite: "platinum_ore.png", count: 4 }
    ],
    "Аэролитовый слиток": [
        { name: "Аэролитовая руда", sprite: "aerialite_ore.png", count: 3 }
    ],
    "Слиток адского камня": [
        { name: "Адский камень", sprite: "sub_hellstone.png", count: 3 },
        { name: "Обсидиан", sprite: "obsidian.png", count: 1 }
    ],
    "Солнечный фрагмент": ["Оператор"],
    "Вихревой фрагмент": ["Оператор"],
    "Эссенция ночи": ["Оператор"],
    "Эссенция света": ["Оператор"],
    "Некроплазма": ["Оператор"],
    "Эктоплазма": ["Оператор"],
    "Упавшая звезда": ["Алхимик"],
    "Кристалл жизни": ["Алхимик"],
    "Гель": ["Алхимик"],
    "Фрукт жизни": ["Алхимик"],
    "Обсидиан": ["Архитектор"],
    "Метеоритная руда": ["Подрывник"]
};

const npcTemplates = {
    "Оператор":   { name: "Оператор", sprite: "Operator.png", count: 1 },
    "Алхимик":    { name: "Алхимик", sprite: "alchemist.png", count: 1 },
    "Белка":      { name: "Белка", sprite: "squirrel.png", count: 1 },
    "Архитектор": { name: "Архитектор", sprite: "architect.png", count: 1, customSize: { width: 64, height: 64 } },
    "Подрывник":  { name: "Подрывник", sprite: "demolitionist.png", count: 1, customSize: { width: 54, height: 54 } }
};

// Сопоставление материалов с НПС-продавцами
const npcVendors = {
    "Солнечный фрагмент": "Оператор",
    "Вихревой фрагмент": "Оператор",
    "Освящённый слиток": "Оператор",
    "Эссенция ночи": "Оператор",
    "Эссенция света": "Оператор",
    "Эктоплазма": "Оператор",
    "Некроплазма": "Оператор",
    "Камень из босс раша": "Белка",
    "Гель": "Алхимик",
    "Кристалл жизни": "Алхимик",
    "Упавшая звезда": "Алхимик",
    "Фрукт жизни": "Алхимик",
    "Обсидиан": "Архитектор",
    "Адский камень": "Подрывник",
    "Метеоритная руда": "Подрывник"
};

// Сопоставление материалов с боссами (после какого босса доступен)
const bossRequirements = {
    // Пре-хардмод
    "Метеоритная руда": "Разбить Теневую сферу/Багровое сердце",
    "Метеоритный слиток": "Разбить Теневую сферу/Багровое сердце",
    "Адский камень": "До хардмода (Преисподняя)",
    "Адский слиток": "До хардмода (Преисподняя)",
    "Обсидиан": "До хардмода (вода + лава)",
    "Кровавая сфера": "Кровавая луна (до хардмода)",

    // Хардмод (после Стены Плоти)
    "Эссенция прозрения": "Хардмод (после Стены Плоти)",
    "Эссенция света": "Хардмод (после Стены Плоти)",
    "Эссенция ночи": "Хардмод (после Стены Плоти)",
    "Эссенция ужаса": "Хардмод (после Стены Плоти)",
    "Эссенция полёта": "Хардмод (после Стены Плоти)",
    "Эссенция могущества": "Хардмод (после Стены Плоти)",

    "Крионитовая руда": "Криоген",
    "Многолетняя руда": "Плантера",
    "Магматитовая руда": "Голем",
    "Крионитовый слиток": "Криоген",
    "Многолетний слиток": "Плантера",
    "Магматитовый слиток": "Голем",
    "Сплав Жизни": "Голем",
    "Фрукт жизни": "Механические боссы",
    "Живой осколок": "Плантера",
    "Чудо фрукт": "Голем",
    "Эктоплазма": "Плантера",
    "Некроплазма": "Полтергаст",
    "Освящённый слиток": "Механические боссы",
    "Хлорофитовая руда": "Механические боссы",
    "Хлорофитовый слиток": "Механические боссы",
    "Спектральный слиток": "Механические боссы",
    "Грибнитовый слиток": "Механические боссы",
    "Аэролитовая руда": "Разум улья / Перфоратор",
    "Аэролитовый слиток": "Разум улья / Перфоратор",

    // События
    "Фрагмент тёмного солнца": "Солнечное затмение",
    "Эндотермическая энергия": "Ледяная королева (Морозная луна)",
    "Кошмарное топливо": "Тыквенный король (Тыквенная луна)",

    // Пост-Лунный Лорд
    "Люминитовая руда": "Лунный Лорд",
    "Люминитовый слиток": "Лунный Лорд",
    "Солнечный фрагмент": "Солнечная башня",
    "Вихревой фрагмент": "Вихревая башня",
    "Туманный фрагмент": "Туманная башня",
    "Звёздный фрагмент": "Звёздная башня",
    "Астральная руда": "Астральное Заражение",
    "Астральный слиток": "Астральное Заражение",
    "Звёздная сажа": "Астральное Заражение",
    "Астральное желе": "Астрагельдон",
    "Руда метановы": "Астрагельдон",
    "Слиток метановы": "Астрагельдон",
    "Цветонитовая руда": "Лунный Лорд",
    "Цветонитовый слиток": "Лунный Лорд",
    "Осквернённая морошка": "Лунный Лорд",

    // Финальные материалы
    "Экзо-призма": "Экзо-мехи",
    "Пепел аннигиляции": "Высшая ведьма, Каламитас",
    "Тёмная плазма": "Нескончаемая пустота",
    "Искривлённая пустота": "Сигнус",
    "Бронированный панцирь": "Штормовой Ткач",
    "Пепел бедствия": "Клон Каламитас",
    "Божественная жеода": "Провиденс",
    "Губительная душа": "Полтергаст",
    "Девиантная энергия": "Девиант",
    "Мерзкая энергия": "Мерзость",
    "Вечная энергия": "Мутант",
    "Камень из босс раша": "Boss RUSH",
    "Ауритовая руда": "Ярон",
    "Ауритовый слиток": "Ярон",
    "Фрагмент души Ярона": "Ярон",
    "Хроматическая масса": "Гузма",
    "Тенефазовый слиток": "Мутант",
    "Эссенция восходящего духа": "Пожиратель Богов",
    "Космилитовый слиток": "Пожиратель Богов",
    "Дивная материя": "Экзо-мехи",
    "Кровавый мандарин": "Хардмод (после Стены Плоти)",
    "Священная клубника": "Ярон",

    // Базовые материалы
    "Гель": "С самого начала",
    "Кристалл жизни": "С самого начала",
    "Упавшая звезда": "С самого начала",
    "Кристалл маны": "С самого начала"
};

// Спрайты боссов
const bossSprites = {
    "Криоген": "boss_cryogen.png",
    "Многолетний Повелитель": "boss_perforators.png",
    "Бедствие": "boss_calamitas_clone.png",
    "Плантера": "boss_plantera.gif",
    "Полтергаст": "boss_polterghast.png",
    "Голем": "Golem.png",
    "Лунный Лорд": "boss_moon_lord.gif",
    "Солнечная башня": "Solar_Pillar.png",
    "Вихревая башня": "Vortex_Pillar.png",
    "Туманная башня": "Nebula_Pillar.png",
    "Звёздная башня": "Stardust_Pillar.png",
    "Астральное Заражение": "BiomeBannerAstralInfection.png",
    "Астрагельдон": "boss_astrageldon.gif",
    "Высшая ведьма, Каламитас": "boss_supreme_calamitas.png",
    "Нескончаемая пустота": "boss_ceaseless_void.png",
    "Сигнус": "boss_signus.png",
    "Штормовой Ткач": "boss_storm_weaver.png",
    "Клон Каламитас": "boss_calamitas_clone.png",
    "Провиденс": "boss_providence.png",
    "Опустошитель": "boss_ravager.png",
    "Девиант": "Deviantt_(boss).png",
    "Мерзость": "Abominationn_(boss).png",
    "Мутант": "Mutant_(boss).png",
    "Механические боссы": "Mechdusa.png",
    "Экзо-мехи": "Dreadon.png",
    "Boss RUSH": "terminus.png",
    "Стена Плоти": "WallofFlesh.png",
    "Хардмод (после Стены Плоти)": "WallofFlesh.png",
    "Кровавая луна": "BloodMoon.png",
    "Кровавая луна (до хардмода)": "BloodMoon.png",
    "Ярон": "boss_yharon.png",
    "Гузма": "Goozma.gif",
    "Солнечное затмение": "SolarEclipse.png",
    "Ледяная королева (Морозная луна)": "FrostMoon.png",
    "Тыквенный король (Тыквенная луна)": "PumpkinMoon.png",
    "Пожиратель Богов": "boss_devourer.png",
    "Разум улья / Перфоратор": "TheHiveMind.png"
};

// ============================================================
// СТАНЦИИ (рабочие места)
// Каждая станция — это отдельный спрайт + человекочитаемое имя.
// Спрайты OSP.png и crucible.png уже лежат в папке; остальные
// (titanium_forge.png, furnace.png, hellforge.png,
// ancient_manipulator.png) докачиваются из вики, либо их нужно
// положить вручную — на случай отсутствия файла стоит onerror-плейсхолдер.
// ============================================================
const stations = {
    osp:          { name: "Агрегатор материи конца (OSP)", sprite: "OSP.png" },
    draedon:      { name: "Кузня Дрэйдона",              sprite: "Draedon'sForge.png" },
    cosmic:       { name: "Космическая наковальня",      sprite: "CosmicAnvil.png" },
    mythril:      { name: "Мифриловая наковальня",       sprite: "mythril_anvil.png" },
    titanium:     { name: "Титановая кузня",             sprite: "titanium_forge.png" },
    furnace:      { name: "Печь",                        sprite: "furnace.png" },
    hellforge:    { name: "Адская кузня",                sprite: "hellforge.png" },
    autohammer:   { name: "Автомолот",                   sprite: "Autohammer.png" },
    manipulator:  { name: "Древний манипулятор",         sprite: "ancient_manipulator.png" }
};

// Сопоставление «имя предмета → ключ станции». Любой материал,
// которого здесь нет, считается получаемым без станции (дроп/НПС/ресурс)
// — для него панель покажет «Без станции».
const stationLookup = {
    // --- OSP: финальные предметы ---
    "Унитаз Бесконечности":           "osp",
    "Сплав Бесконечности":            "osp",
    "Катализатор Бесконечности":      "osp",
    "Призрачное вещество":            "osp",
    "Аморфное вещество":              "osp",
    "Распадающееся вещество":         "osp",
    "Мнимая частица":                 "osp",
    "Сплав сверхплотной нейтронной звезды": "osp",
    "Шар тёмной материи":             "osp",

    // --- Кузня Дрэйдона ---
    "Тенефазовый слиток":             "draedon",

    // --- Космическая наковальня ---
    "Ауритовый слиток":               "cosmic",
    "Священная клубника":             "cosmic",

    // --- Мифриловая наковальня ---
    "Сплав Жизни":                    "mythril",
    "Чудо фрукт":                     "mythril",
    "Кровавый мандарин":              "mythril",
    "Осквернённая морошка":           "mythril",

    // --- Титановая кузня ---
    "Крионитовый слиток":             "titanium",
    "Многолетний слиток":             "titanium",
    "Магматитовый слиток":            "titanium",
    "Хлорофитовый слиток":            "titanium",
    "Спектральный слиток":            "titanium",
    "Цветонитовый слиток":            "titanium",

    // --- Автомолот ---
    "Грибнитовый слиток":             "autohammer",

    // --- Адская кузня ---
    "Адский слиток":                  "hellforge",
    "Слиток адского камня":           "hellforge",

    // --- Печь ---
    "Метеоритный слиток":             "furnace",
    "Платиновый слиток":              "furnace",
    "Аэролитовый слиток":             "furnace",

    // --- Древний манипулятор ---
    "Слиток метановы":                "manipulator",
    "Люминитовый слиток":             "manipulator",
    "Эссенция восходящего духа":      "manipulator"
};

// Насколько плавно едут узлы/линии при перестроении дерева.
const TRANSITION_MS = 400;

// ============================================================
// ОТРИСОВКА
// ============================================================
const svg = d3.select("#canvas"),
      width = window.innerWidth,
      height = window.innerHeight;

const g = svg.append("g");
const linksLayer = g.append("g").attr("class", "links-layer");
const nodesLayer = g.append("g").attr("class", "nodes-layer");
const badgesLayer = g.append("g").attr("class", "badges-layer");

const zoom = d3.zoom()
    .scaleExtent([0.2, 3])
    .on("zoom", (event) => g.attr("transform", event.transform));

svg.call(zoom);

const treeLayout = d3.tree().nodeSize([45, 240]);
let root = d3.hierarchy(craftData);

root.x0 = height / 2;
root.y0 = 80;

// При открытии сайта дерево должно быть полностью свёрнуто —
// даже захардкоженная ветка "Катализатор Бесконечности" (в отличие
// от лениво подгружаемых recipesLookup-веток она приходит в craftData
// уже раскрытой), поэтому сворачиваем её так же, как обычное закрытие
// ветки по клику.
collapseNode(root);
updateTree(root);

// Корневой узел при свёрнутом дереве всегда лежит в координатах
// (0,0) — центрируем его на середине экрана, пока пользователь
// сам не начнёт панить/зумить.
svg.call(zoom.transform, d3.zoomIdentity.translate(width / 2, height / 2));

function updateTree(source) {
    // Защита от "разлёта" дерева: если updateTree вызвали для узла,
    // у которого ещё не сохранена предыдущая позиция (x0/y0), enter-
    // селекция подставит NaN в transform, и элемент прыгнет из
    // угла экрана вместо плавного появления рядом с родителем.
    if (source.x0 === undefined) source.x0 = source.x ?? height / 2;
    if (source.y0 === undefined) source.y0 = source.y ?? 80;

    const treeData = treeLayout(root);
    const nodes = treeData.descendants();
    const links = treeData.links();

    nodes.forEach(d => {
        // Проверяем direction в узле или его родителях
        let direction = 1;
        let curr = d;
        while (curr) {
            if (curr.data.direction !== undefined) {
                direction = curr.data.direction;
                break;
            }
            curr = curr.parent;
        }

        // Для левой ветки инвертируем координату y
        const baseY = d.depth * 240 + 80;
        d.y = direction === -1 ? -baseY + 160 : baseY;
    });

    // ---------- Линии ----------
    const linkSelection = linksLayer.selectAll(".link")
        .data(links, d => d.target.id || (d.target.id = Math.random().toString()));

    const linkEnter = linkSelection.enter().append("path")
        .attr("class", "link")
        .attr("d", () => diagonal({ x: source.x0, y: source.y0 }, { x: source.x0, y: source.y0 }));

    linkSelection.merge(linkEnter)
        .transition().duration(TRANSITION_MS)
        .attr("d", d => diagonal(d.source, d.target));

    linkSelection.exit()
        .transition().duration(TRANSITION_MS)
        .attr("d", () => diagonal({ x: source.x, y: source.y }, { x: source.x, y: source.y }))
        .remove();

    // ---------- Узлы ----------
    const nodeSelection = nodesLayer.selectAll(".node")
        .data(nodes, d => d.id || (d.id = Math.random().toString()));

    const nodeEnter = nodeSelection.enter().append("g")
        .attr("class", "node")
        .attr("id", d => `node-${uniqueSlug(d)}`)
        .attr("transform", () => `translate(${source.y0},${source.x0})`)
        .on("click", handleNodeClick);

    nodeEnter.append("image")
        .attr("xlink:href", d => d.data.sprite)
        .attr("width", d => d.data.customSize ? d.data.customSize.width : 32)
        .attr("height", d => d.data.customSize ? d.data.customSize.height : 32)
        .attr("x", d => d.data.customSize ? -(d.data.customSize.width / 2) : -16)
        .attr("y", d => d.data.customSize ? -(d.data.customSize.height / 2) : -16)
        .on("error", function () {
            d3.select(this).attr("xlink:href",
                "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='32' height='32'><rect width='32' height='32' fill='%23334155'/></svg>");
        });

    nodeEnter.append("text")
        .attr("dy", ".35em")
        .attr("x", d => d.data.customSize ? (d.data.customSize.width / 2 + 6) : 22)
        .attr("text-anchor", "start")
        .text(d => d.data.name);

    nodeSelection.merge(nodeEnter)
        .transition().duration(TRANSITION_MS)
        .attr("transform", d => `translate(${d.y},${d.x})`);

    nodeSelection.exit()
        .transition().duration(TRANSITION_MS)
        .attr("transform", () => `translate(${source.y},${source.x})`)
        .remove();

    // ---------- Счётчики ----------
    const visibleBadges = nodes.filter(d => d.data.count > 1);
    const badgeSelection = badgesLayer.selectAll(".count-badge")
        .data(visibleBadges, d => d.id);

    const badgeEnter = badgeSelection.enter().append("g")
        .attr("class", "count-badge")
        .attr("transform", () => `translate(${source.y0},${source.x0})`);

    badgeEnter.append("text")
        .attr("dy", ".35em")
        .attr("x", -24)
        .attr("text-anchor", "end")
        .text(d => `x${d.data.count}`);

    const badgeUpdate = badgeSelection.merge(badgeEnter);
    badgeUpdate.transition().duration(TRANSITION_MS)
        .attr("transform", d => `translate(${d.y},${d.x})`);
    badgeUpdate.select("text").text(d => `x${d.data.count}`);

    badgeSelection.exit()
        .transition().duration(TRANSITION_MS)
        .attr("transform", () => `translate(${source.y},${source.x})`)
        .remove();

    nodes.forEach(d => {
        d.x0 = d.x;
        d.y0 = d.y;
    });
}

function diagonal(s, d) {
    return `M ${s.y} ${s.x}
            C ${(s.y + d.y) / 2} ${s.x},
              ${(s.y + d.y) / 2} ${d.x},
              ${d.y} ${d.x}`;
}

function slugify(name) {
    return name
        .toLowerCase()
        .replace(/[^a-z0-9а-яё]+/gi, '-')
        .replace(/(^-|-$)/g, '');
}

// Уникальный слаг с глубиной, чтобы "Сплав Жизни" в разных ветках не конфликтовал
function uniqueSlug(d) {
    return `${slugify(d.data.name)}-${d.depth}-${d.id}`;
}

// ============================================================
// FOCUS MODE + ПАНЕЛЬ СТАНЦИЙ
// Раньше классы .dimmed/.active/.selected расставлялись вручную
// в нескольких местах handleNodeClick — из-за этого легко было
// забыть снять/поставить класс где-то одном из веток (обычной
// и телепорт-веток), и подсветка "залипала". Теперь это два
// компактных, детерминированных шага, которые вызываются в
// любой ветке клика одинаково.
// ============================================================

function setFocus(selectedNode) {
    const pathToRoot = new Set();
    let curr = selectedNode;
    while (curr) {
        pathToRoot.add(curr);
        curr = curr.parent;
    }

    // Проверяем, продаётся ли выбранный материал у НПС
    const vendorNPC = npcVendors[selectedNode.data.name];
    const npcNodesToHighlight = new Set();

    if (vendorNPC) {
        // Находим все узлы с этим НПС в дереве
        root.descendants().forEach(n => {
            if (n.data.name === vendorNPC) {
                npcNodesToHighlight.add(n);
            }
        });
    }

    nodesLayer.selectAll(".node")
        .classed("selected", d => d === selectedNode)
        .classed("highlighted", d => pathToRoot.has(d) || npcNodesToHighlight.has(d))
        .classed("dimmed", d => !pathToRoot.has(d) && !npcNodesToHighlight.has(d));

    // Линии на пути к выбранному узлу подсвечиваются ярче базового
    // свечения, остальные гаснут.
    linksLayer.selectAll(".link")
        .classed("active", d => pathToRoot.has(d.target))
        .classed("dimmed", d => !pathToRoot.has(d.target));
}

// Динамическая панель боссов: показываем после какого босса доступен материал
function setBossFocus(node) {
    const panel = d3.select("#boss-panel");
    const content = d3.select("#boss-content");
    content.selectAll("*").remove();

    const name = node && node.data ? node.data.name : null;
    const bossInfo = name ? bossRequirements[name] : null;

    if (bossInfo) {
        const info = content.append("div").attr("class", "boss-info");
        const infoContent = info.append("div").attr("class", "boss-info-content");
        infoContent.append("span").attr("class", "boss-label").text("Доступно после");
        infoContent.append("span").attr("class", "boss-name").text(bossInfo);
        panel.classed("visible", true);
    } else {
        panel.classed("visible", false);
    }
}

// Динамическая панель со спрайтом босса
function setBossSpriteFocus(node) {
    const panel = d3.select("#boss-sprite-panel");
    const content = d3.select("#boss-sprite-content");
    content.selectAll("*").remove();

    const name = node && node.data ? node.data.name : null;
    const bossName = name ? bossRequirements[name] : null;
    const bossSprite = bossName ? bossSprites[bossName] : null;

    if (bossSprite) {
        const container = content.append("div").attr("class", "boss-sprite-container");
        container.append("img")
            .attr("src", bossSprite)
            .attr("alt", bossName)
            .on("error", function() {
                this.style.background = "#334155";
                this.style.width = "80px";
                this.style.height = "80px";
            });
        container.append("span").attr("class", "boss-sprite-name").text(bossName);
        panel.classed("visible", true);
    } else {
        panel.classed("visible", false);
    }
}

// Динамическая панель: при клике по узлу показываем станцию,
// минимально нужную для ЭТОГО предмета (по stationLookup). Если
// предмет крафтится без станции (дроп/НПС/ресурс) — пишем «Без станции».
// Панель изначально скрыта и «всплывает» только после первого клика.
function setStationFocus(node) {
    const panel = d3.select("#stations-panel");
    const content = d3.select("#station-content");
    content.selectAll("*").remove();

    const name = node && node.data ? node.data.name : null;
    const key = name ? stationLookup[name] : null;

    if (key && stations[key]) {
        const st = stations[key];
        const row = content.append("div").attr("class", "station-row active");
        row.append("img")
            .attr("src", st.sprite)
            .attr("alt", st.name)
            .on("error", function () { this.style.background = "#334155"; });
        const info = row.append("div").attr("class", "station-info");
        info.append("span").attr("class", "station-name").text(st.name);
        info.append("span").attr("class", "station-items").text("Нужно для: " + name);
    } else {
        const row = content.append("div").attr("class", "station-row active no-station");
        const info = row.append("div").attr("class", "station-info");
        info.append("span").attr("class", "station-name").text("Без станции");
        info.append("span").attr("class", "station-items").text("Дроп / НПС / ресурс");
    }

    panel.classed("visible", true);
}

// ============================================================
// КЛИК ПО УЗЛУ
// ============================================================
// Кеш координат для телепорт-линий (чтобы линия не прыгала)
const teleportTargetCache = {};

function handleNodeClick(event, d) {
    g.selectAll(".teleport-link").remove();

    // ---------- Жёсткие привязки телепорт-линий ----------
    // Каждый материал может иметь несколько правил (проверяются по порядку)
    const teleportLinks = {
        "Катализатор Бесконечности": [
            { fromDepth: 2, toDepth: 1 }  // Из левой ветки → в правую
        ],
        "Распадающееся вещество": [
            {}  // Любой → к ближайшему с меньшим depth
        ],
        "Мнимая частица": [
            {}  // Любой → к ближайшему с меньшим depth
        ],
        "Тенефазовый слиток": [
            { fromDepth: 4, toDepth: 2, targetCount: 9 }  // тф5 → тф2 (первый с 9 шт)
        ],
        "Ауритовый слиток": [
            { fromDepth: 5, toDepth: 3, targetParent: "Тенефазовый слиток", targetParentCount: 9, sourceParent: "Шар тёмной материи" },   // аурит из Шара → аурит внутри ТФ(9шт) в Сплаве Беск
            { fromDepth: 4, toDepth: 3, targetParent: "Тенефазовый слиток", targetParentCount: 9 }  // аурит из ССНЗ → аурит внутри ТФ(9шт)
        ],
        "Сплав Жизни": [
            { fromDepth: 2, toDepth: 1, targetParent: "Катализатор Бесконечности" }  // Сплав Жизни → Чудо фрукт в правой ветке
        ]
    };

    // ---------- Проверка на телепорт-линию ----------
    if (teleportLinks[d.data.name]) {
        const rules = teleportLinks[d.data.name];

        // Функция глубокого поиска
        function findAllPotentialOccurrences(targetName, clickedNode) {
            const candidates = [];
            const nodesToRestore = [];

            function scanNode(node) {
                if (node.data.name === targetName && node !== clickedNode && node.depth < clickedNode.depth) {
                    candidates.push(node);
                }
                if (node.children) {
                    node.children.forEach(child => scanNode(child));
                }
                if (node._children && !node.children) {
                    node.children = node._children;
                    node._children = null;
                    nodesToRestore.push(node);
                    node.children.forEach(child => scanNode(child));
                }
                if (!node.children && !node._children) {
                    const recipe = recipesLookup[node.data.name];
                    if (recipe) {
                        expandNode(node);
                        if (node.children) {
                            nodesToRestore.push(node);
                            node.children.forEach(child => scanNode(child));
                        }
                    }
                }
            }

            scanNode(root);

            const tempTreeData = treeLayout(root);
            const tempNodes = tempTreeData.descendants();

            tempNodes.forEach(n => {
                let direction = 1;
                let curr = n;
                while (curr) {
                    if (curr.data.direction !== undefined) {
                        direction = curr.data.direction;
                        break;
                    }
                    curr = curr.parent;
                }
                const baseY = n.depth * 240 + 80;
                n.y = direction === -1 ? -baseY + 160 : baseY;
            });

            const candidatesWithPositions = candidates.map(candidate => {
                const updated = tempNodes.find(n =>
                    n.data.name === candidate.data.name && n.depth === candidate.depth
                );
                return updated || candidate;
            });

            nodesToRestore.forEach(node => {
                if (node.children) {
                    node._children = node.children;
                    node.children = null;
                }
            });

            return candidatesWithPositions;
        }

        const allCandidates = findAllPotentialOccurrences(d.data.name, d);
        let targetNode = null;
        let matchedRule = null;

        console.log(`=== Телепорт для: ${d.data.name}, depth=${d.depth} ===`);
        console.log(`Найдено кандидатов: ${allCandidates.length}`);
        allCandidates.forEach((c, i) => {
            // Строим путь до узла для отладки
            let path = [];
            let temp = c;
            while (temp && temp.parent) {
                path.unshift(temp.parent.data?.name || 'root');
                temp = temp.parent;
            }
            const grandparent = c.parent?.parent?.data?.name || 'нет';
            console.log(`  Кандидат ${i+1}: depth=${c.depth}, родитель: ${c.parent?.data?.name} (depth=${c.parent?.depth}), дедушка: ${grandparent}, путь: ${path.join(' → ')}`);
        });

        // Проверяем правила по порядку
        for (const rule of rules) {
            console.log(`Проверка правила: fromDepth=${rule.fromDepth}, toDepth=${rule.toDepth}, targetParent=${rule.targetParent}`);

            if (rule.fromDepth !== undefined && rule.toDepth !== undefined) {
                if (d.depth === rule.fromDepth) {
                    // Проверяем sourceParent (родителя исходного узла)
                    if (rule.sourceParent && d.parent?.data?.name !== rule.sourceParent) {
                        console.log(`⏭️ Правило пропущено - sourceParent не совпадает (нужен ${rule.sourceParent}, есть ${d.parent?.data?.name})`);
                        continue;
                    }

                    // Ищем целевой узел с учётом родителя
                    const possibleTargets = allCandidates.filter(n => {
                        if (n.depth !== rule.toDepth) return false;
                        if (rule.targetParent && n.parent?.data?.name !== rule.targetParent) return false;
                        if (rule.targetCount !== undefined && n.data.count !== rule.targetCount) return false;
                        if (rule.targetParentCount !== undefined && n.parent?.data?.count !== rule.targetParentCount) return false;
                        return true;
                    });

                    if (possibleTargets.length > 0) {
                        // Если несколько кандидатов:
                        // 1. Сортируем по depth родителя (ближе к корню)
                        // 2. Если равны - по индексу родителя в children дедушки (первый в списке)
                        targetNode = possibleTargets.sort((a, b) => {
                            const depthDiff = (a.parent?.depth || 0) - (b.parent?.depth || 0);
                            if (depthDiff !== 0) return depthDiff;

                            // Находим индексы родителей в children дедушки
                            const grandpaA = a.parent?.parent;
                            const grandpaB = b.parent?.parent;
                            if (grandpaA && grandpaB && grandpaA === grandpaB && grandpaA.children) {
                                const indexA = grandpaA.children.indexOf(a.parent);
                                const indexB = grandpaB.children.indexOf(b.parent);
                                return indexA - indexB; // Берём того, чей родитель раньше в списке
                            }
                            return 0;
                        })[0];

                        matchedRule = rule;
                        const parentIndex = targetNode.parent?.parent?.children?.indexOf(targetNode.parent) ?? -1;
                        console.log(`✅ Правило сработало! Найдено ${possibleTargets.length} узлов, выбран с depth=${targetNode.depth}, родитель depth=${targetNode.parent?.depth}, индекс родителя в children: ${parentIndex}`);
                        break;
                    } else {
                        console.log(`❌ Правило не подошло - узел не найден`);
                    }
                } else {
                    console.log(`⏭️ Правило пропущено - depth не совпадает (нужен ${rule.fromDepth}, есть ${d.depth})`);
                }
            } else if (rule.toDepth !== undefined) {
                targetNode = allCandidates.find(n => n.depth === rule.toDepth);
                if (targetNode) {
                    matchedRule = rule;
                    console.log(`✅ Привязка к toDepth=${rule.toDepth}, найден`);
                    break;
                }
            } else {
                targetNode = allCandidates.filter(n => n.depth < d.depth).sort((a, b) => a.depth - b.depth)[0];
                if (targetNode) {
                    matchedRule = rule;
                    console.log(`✅ Ближайший с меньшим depth, найден`);
                    break;
                }
            }
        }

        if (!targetNode) {
            console.log(`❌ Целевой узел НЕ найден ни по одному правилу`);
        }

        if (targetNode) {
            const realNode = root.descendants().find(n =>
                n.data.name === targetNode.data.name && n.depth === targetNode.depth
            );

            if (!realNode) {
                let pathToNode = [];
                let temp = targetNode;
                while (temp && temp !== root) {
                    pathToNode.unshift(temp);
                    temp = temp.parent;
                }

                let current = root;
                for (let i = 0; i < pathToNode.length - 1; i++) {
                    const nextNode = current.children?.find(child =>
                        child.data.name === pathToNode[i + 1].data.name
                    ) || current._children?.find(child =>
                        child.data.name === pathToNode[i + 1].data.name
                    );

                    if (!nextNode) {
                        if (!current.children && !current._children) {
                            expandNode(current);
                        } else if (current._children) {
                            current.children = current._children;
                            current._children = null;
                        }
                    }

                    current = nextNode || current.children?.find(child =>
                        child.data.name === pathToNode[i + 1].data.name
                    );

                    if (!current) break;
                }

                updateTree(root);

                const finalNode = root.descendants().find(n =>
                    n.data.name === targetNode.data.name && n.depth === targetNode.depth
                );

                if (finalNode) {
                    setTimeout(() => {
                        const drawTeleportAndFocus = () => {
                            g.append("path")
                                .attr("class", "teleport-link")
                                .attr("d", diagonal(d, finalNode))
                                .style("opacity", 1)
                                .transition()
                                .delay(3000)
                                .style("opacity", 0)
                                .remove();

                            setFocus(finalNode);
                            setBossFocus(finalNode);
                            setBossSpriteFocus(finalNode);
                            setStationFocus(finalNode);
                        };

                        if (finalNode._children) {
                            finalNode.children = finalNode._children;
                            finalNode._children = null;
                            updateTree(finalNode);
                            setTimeout(drawTeleportAndFocus, TRANSITION_MS + 20);
                        } else if (!finalNode.children) {
                            expandNode(finalNode);
                            updateTree(finalNode);
                            setTimeout(drawTeleportAndFocus, TRANSITION_MS + 20);
                        } else {
                            drawTeleportAndFocus();
                        }
                    }, TRANSITION_MS + 20);
                }
                return;
            }

            const drawTeleportAndFocus = () => {
                // Создаём ключ для кеширования (имя + depth исходного и целевого узла)
                const cacheKey = `${d.data.name}_${d.depth}_to_${realNode.data.name}_${realNode.depth}`;

                // Если координат нет в кеше - сохраняем текущие для ОБОИХ узлов
                if (!teleportTargetCache[cacheKey]) {
                    teleportTargetCache[cacheKey] = {
                        source: { x: d.x, y: d.y },
                        target: { x: realNode.x, y: realNode.y }
                    };
                }

                // Создаём виртуальные узлы с зафиксированными координатами
                const fixedSourceNode = {
                    x: teleportTargetCache[cacheKey].source.x,
                    y: teleportTargetCache[cacheKey].source.y,
                    data: d.data
                };

                const fixedTargetNode = {
                    x: teleportTargetCache[cacheKey].target.x,
                    y: teleportTargetCache[cacheKey].target.y,
                    data: realNode.data
                };

                g.append("path")
                    .attr("class", "teleport-link")
                    .attr("d", diagonal(fixedSourceNode, fixedTargetNode))  // Используем зафиксированные координаты
                    .style("opacity", 1)
                    .transition()
                    .delay(3000)
                    .style("opacity", 0)
                    .remove();

                setFocus(realNode);
                setBossFocus(realNode);
                setBossSpriteFocus(realNode);
                setStationFocus(realNode);
            };

            if (realNode._children) {
                realNode.children = realNode._children;
                realNode._children = null;
                updateTree(realNode);
                setTimeout(drawTeleportAndFocus, TRANSITION_MS + 20);
            } else if (!realNode.children) {
                expandNode(realNode);
                updateTree(realNode);
                setTimeout(drawTeleportAndFocus, TRANSITION_MS + 20);
            } else {
                drawTeleportAndFocus();
            }
            return;
        }
    }

    // ---------- Стандартный клик ----------
    if (event && event.currentTarget) {
        d3.select(event.currentTarget);
    }

    if (d.children) {
        collapseNode(d);

        const duplicates = root.descendants().filter(n =>
            n !== d && n.data.name === d.data.name && n.children
        );
        duplicates.forEach(collapseNode);
    } else if (d._children) {
        d.children = d._children;
        d._children = null;
    } else {
        expandNode(d);
    }

    updateTree(d);
    setFocus(d);
    setBossFocus(d);
    setBossSpriteFocus(d);
    setStationFocus(d);
}

// Рекурсивно сворачивает узел вместе со всем, что было раскрыто
// внутри него (иначе при повторном открытии ветка "вспомнила" бы
// вложенные раскрытия, которые пользователь не видит на схлопнутом
// дереве, а закрытие "по цепочке" из handleNodeClick закрыло бы
// только верхний уровень дублирующегося узла).
function collapseNode(d) {
    if (d.children) {
        d.children.forEach(collapseNode);
        d._children = d.children;
        d.children = null;
    }
}

// Достаёт под-рецепт из recipesLookup и превращает его в детей узла d.
function expandNode(d) {
    const subRecipe = recipesLookup[d.data.name];
    if (!subRecipe) return;

    // Ищем спрайт по всему дереву (root.descendants()), а не только
    // среди прямых детей Катализатора — иначе вложенные под-рецепты
    // (например, "Сплав Жизни" внутри "Чудо фрукт") не получат картинку.
    const allKnownItems = root.descendants()
        .map(n => n.data)
        .filter(Boolean);

    d.children = subRecipe.map(rawItem => {
        let item;
        if (typeof rawItem === "string") {
            item = { ...npcTemplates[rawItem] };
        } else {
            item = { ...rawItem };
        }

        const exactMatch = allKnownItems.find(m => m.name === item.name);
        if (exactMatch) {
            item.sprite = exactMatch.sprite;
            if (exactMatch.customSize) item.customSize = exactMatch.customSize;
        }

        const newNode = d3.hierarchy(item);
        newNode.depth = d.depth + 1;
        newNode.parent = d;
        newNode.x0 = d.x;
        newNode.y0 = d.y;
        return newNode;
    });
}

window.addEventListener('resize', () => {
    svg.attr("width", window.innerWidth).attr("height", window.innerHeight);
});

// ============================================================
// АНИМИРОВАННЫЙ КОСМИЧЕСКИЙ ФОН
// Туманность — на CSS (см. #cosmic-bg / @keyframes nebula-drift),
// а мерцающие/дрейфующие звёзды рисуются здесь через canvas —
// на CSS-градиентах убедительное мерцание не сделать.
// ============================================================
(function initStarfield() {
    const canvas = document.getElementById("cosmic-bg");
    const ctx = canvas.getContext("2d");

    let stars = [];
    const STAR_COUNT = 160;

    function resize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        stars = Array.from({ length: STAR_COUNT }, () => ({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            r: Math.random() * 1.3 + 0.3,
            baseAlpha: Math.random() * 0.5 + 0.3,
            twinkleSpeed: Math.random() * 0.02 + 0.005,
            phase: Math.random() * Math.PI * 2,
            driftX: (Math.random() - 0.5) * 0.04,
            driftY: (Math.random() - 0.5) * 0.04
        }));
    }

    function tick(t) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        for (const s of stars) {
            s.x += s.driftX;
            s.y += s.driftY;
            if (s.x < 0) s.x = canvas.width;
            if (s.x > canvas.width) s.x = 0;
            if (s.y < 0) s.y = canvas.height;
            if (s.y > canvas.height) s.y = 0;

            const alpha = s.baseAlpha + Math.sin(t * s.twinkleSpeed + s.phase) * 0.35;
            ctx.beginPath();
            ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(226, 232, 240, ${Math.max(0, alpha)})`;
            ctx.fill();
        }
        requestAnimationFrame(tick);
    }

    window.addEventListener("resize", resize);
    resize();
    requestAnimationFrame(tick);
})();

// ============================================================
// ФОНОВАЯ МУЗЫКА
// Браузеры блокируют автозапуск звука без жеста пользователя,
// поэтому это простой play/pause по клику, а не автовоспроизведение.
// ============================================================
(function initMusicToggle() {
    const audio = document.getElementById("bg-audio");
    const button = document.getElementById("music-toggle");
    const playIcon = button.querySelector(".play-icon");
    const pauseIcon = button.querySelector(".pause-icon");
    const volumeSlider = document.getElementById("volume-slider");
    audio.volume = 0.4;

    button.addEventListener("click", () => {
        if (audio.paused) {
            audio.play().catch(() => {
                // Файл музыки не найден/не подставлен — просто не включаем.
            });
            button.classList.add("playing");
            if (playIcon) playIcon.style.display = "none";
            if (pauseIcon) pauseIcon.style.display = "block";
        } else {
            audio.pause();
            button.classList.remove("playing");
            if (playIcon) playIcon.style.display = "block";
            if (pauseIcon) pauseIcon.style.display = "none";
        }
    });

    // Регулировка громкости
    volumeSlider.addEventListener("input", (e) => {
        audio.volume = e.target.value / 100;
    });
})();

// ============================================================
// ПАНЕЛЬ МАТЕРИАЛОВ
// ============================================================
(function initMaterialsPanel() {
    const materialsButton = document.getElementById("materials-button");
    const materialsPanel = document.getElementById("materials-panel");
    const materialsClose = document.getElementById("materials-close");
    const materialsContent = document.getElementById("materials-content");
    const panelSound = document.getElementById("panel-sound");

    // Функция глубокого подсчёта всех материалов до самого базового уровня
    function calculateAllMaterials() {
        const materials = {};

        function addMaterial(itemName, itemSprite, count) {
            if (!materials[itemName]) {
                materials[itemName] = {
                    name: itemName,
                    sprite: itemSprite,
                    count: 0
                };
            }
            materials[itemName].count += count;
        }

        function processNode(node, multiplier) {
            const nodeName = node.name;
            const nodeSprite = node.sprite;
            const nodeCount = node.count || 1;
            const totalMultiplier = multiplier * nodeCount;

            // Добавляем сам узел
            addMaterial(nodeName, nodeSprite, totalMultiplier);

            // Если у узла есть children в дереве - обрабатываем их
            if (node.children && node.children.length > 0) {
                node.children.forEach(child => {
                    processNode(child, totalMultiplier);
                });
            } else {
                // Если children нет - разворачиваем рецепт из recipesLookup
                const recipe = recipesLookup[nodeName];
                if (recipe && recipe.length > 0) {
                    recipe.forEach(ingredient => {
                        if (typeof ingredient === 'string') {
                            // Босс или условие - пропускаем
                            return;
                        }
                        processNode(ingredient, totalMultiplier);
                    });
                }
            }
        }

        // Проходим по веткам унитаза (не включаем сам унитаз)
        craftData.children.forEach(branch => {
            processNode(branch, 1);
        });

        return materials;
    }

    // Открытие панели
    materialsButton.addEventListener("click", () => {
        const isVisible = materialsPanel.classList.contains("visible");

        if (!isVisible) {
            // Воспроизводим звук
            panelSound.currentTime = 0;
            panelSound.volume = 0.5;
            panelSound.play().catch(() => {});

            // Подсчитываем материалы
            const allMaterials = calculateAllMaterials();

            // Сортируем по количеству (от большего к меньшему)
            const sortedMaterials = Object.values(allMaterials)
                .sort((a, b) => b.count - a.count);

            // Подсчитываем общее количество всех материалов
            const totalCount = sortedMaterials.reduce((sum, m) => sum + m.count, 0);

            // Обновляем заголовок с общим количеством
            const header = materialsPanel.querySelector('h2');
            header.innerHTML = `Все материалы <span class="materials-total">(${totalCount} шт.)</span>`;

            // Заполняем панель
            materialsContent.innerHTML = '';
            sortedMaterials.forEach(material => {
                const item = document.createElement('div');
                item.className = 'material-item';
                item.innerHTML = `
                    <img src="${material.sprite}" alt="${material.name}">
                    <div class="material-info">
                        <div class="material-name">${material.name}</div>
                        <div class="material-count">×${material.count}</div>
                    </div>
                `;
                materialsContent.appendChild(item);
            });

            // Показываем панель
            materialsPanel.classList.add("visible");
        }
    });

    // Закрытие панели
    materialsClose.addEventListener("click", () => {
        materialsPanel.classList.remove("visible");
    });

    // Закрытие при клике вне панели
    document.addEventListener("click", (e) => {
        if (materialsPanel.classList.contains("visible") &&
            !materialsPanel.contains(e.target) &&
            !materialsButton.contains(e.target)) {
            materialsPanel.classList.remove("visible");
        }
    });
})();
